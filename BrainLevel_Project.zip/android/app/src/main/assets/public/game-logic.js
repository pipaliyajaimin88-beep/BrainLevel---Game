// BrainLevel - Complete Game Logic
// game-logic.js

// ========================
// GAME STATE
// ========================
const GameState = {
  currentLevel: 1,
  currentWorld: 1,
  score: 0,
  moves: 15,
  time: 60,
  target: 20,
  tilesCleared: 0,
  hintsLeft: 3,
  undosLeft: 3,
  coins: parseInt(localStorage.getItem('bl_coins') || '0'),
  completedLevels: JSON.parse(localStorage.getItem('bl_completed') || '{}'),
  levelStars: JSON.parse(localStorage.getItem('bl_stars') || '{}'),
  grid: [],
  selectedTile: null,
  previousGrid: null,
  timer: null,
  isAnimating: false,
  isPaused: false
};

// Tile types
const TILE = {
  EMPTY: 0,
  RED: 1,
  BLUE: 2,
  GREEN: 3,
  YELLOW: 4,
  PURPLE: 5,
  BOMB: 'B',
  LOCKED: 'L',
  RAINBOW: 'R'
};

const TILE_EMOJIS = {
  1: '🔴', 2: '🔵', 3: '🟢', 4: '🟡', 5: '🟣',
  'B': '💣', 'L': '🔒', 'R': '🌈'
};

// ========================
// SAVE & LOAD
// ========================
function saveProgress() {
  localStorage.setItem('bl_coins', GameState.coins);
  localStorage.setItem('bl_completed', JSON.stringify(GameState.completedLevels));
  localStorage.setItem('bl_stars', JSON.stringify(GameState.levelStars));
}

function loadProgress() {
  GameState.coins = parseInt(localStorage.getItem('bl_coins') || '0');
  GameState.completedLevels = JSON.parse(localStorage.getItem('bl_completed') || '{}');
  GameState.levelStars = JSON.parse(localStorage.getItem('bl_stars') || '{}');
}

// ========================
// SCREEN NAVIGATION
// ========================
function showScreen(screenId) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  document.getElementById(screenId).classList.add('active');
}

// ========================
// SPLASH SCREEN
// ========================
function initSplash() {
  createParticles();
  let progress = 0;
  const fill = document.getElementById('splash-loader-fill');
  const interval = setInterval(() => {
    progress += 2;
    if (fill) fill.style.width = progress + '%';
    if (progress >= 100) {
      clearInterval(interval);
      setTimeout(() => showScreen('home'), 300);
    }
  }, 50);
}

function createParticles() {
  const container = document.getElementById('splash-particles');
  if (!container) return;
  for (let i = 0; i < 20; i++) {
    const p = document.createElement('div');
    p.className = 'particle';
    p.style.left = Math.random() * 100 + '%';
    p.style.animationDuration = (3 + Math.random() * 4) + 's';
    p.style.animationDelay = (Math.random() * 4) + 's';
    p.style.width = p.style.height = (2 + Math.random() * 4) + 'px';
    const colors = ['#7c3aed', '#8b5cf6', '#3b82f6', '#10b981', '#f59e0b'];
    p.style.background = colors[Math.floor(Math.random() * colors.length)];
    container.appendChild(p);
  }
}

// ========================
// HOME SCREEN
// ========================
function initHome() {
  loadProgress();
  updateCoinDisplay();
}

function updateCoinDisplay() {
  const displays = document.querySelectorAll('.coin-display');
  displays.forEach(d => d.textContent = '🪙 ' + GameState.coins);
}

// ========================
// LEVEL SELECT
// ========================
let levelsData = null;

async function initLevelSelect() {
  if (!levelsData) {
    try {
      const res = await fetch('levels.json');
      levelsData = await res.json();
    } catch (e) {
      console.error('Could not load levels:', e);
      levelsData = { worlds: [] };
    }
  }
  renderLevelGrid(0);
}

function renderLevelGrid(worldIndex) {
  const grid = document.getElementById('level-grid');
  if (!grid || !levelsData) return;
  grid.innerHTML = '';

  const world = levelsData.worlds[worldIndex];
  if (!world || world.locked) return;

  world.levels.forEach((level, i) => {
    const btn = document.createElement('button');
    btn.className = 'level-btn';

    const key = `w${worldIndex + 1}_l${level.id}`;
    const isCompleted = GameState.completedLevels[key];
    const stars = GameState.levelStars[key] || 0;

    // Find active level (first uncompleted)
    const prevKey = i > 0 ? `w${worldIndex + 1}_l${world.levels[i - 1].id}` : null;
    const isActive = !isCompleted && (i === 0 || GameState.completedLevels[prevKey]);
    const isLocked = !isCompleted && !isActive;

    if (isCompleted) {
      btn.classList.add('completed');
      btn.innerHTML = `<span class="level-num">✓</span><span class="level-stars">${'⭐'.repeat(stars)}</span>`;
    } else if (isActive) {
      btn.classList.add('active-level');
      btn.innerHTML = `<span class="level-num">${level.id}</span>`;
    } else {
      btn.classList.add('locked-level');
      btn.innerHTML = `<span class="level-num">🔒</span>`;
    }

    // Difficulty badge
    const badge = document.createElement('span');
    badge.className = `difficulty-badge ${level.difficulty}`;
    badge.textContent = level.difficulty.charAt(0).toUpperCase();
    btn.appendChild(badge);

    if (!isLocked) {
      btn.addEventListener('click', () => startLevel(worldIndex, i));
    }

    grid.appendChild(btn);
  });

  // Update progress bar
  const completed = Object.keys(GameState.completedLevels).filter(k => k.startsWith(`w${worldIndex + 1}`)).length;
  const total = world.levels.length;
  const fill = document.getElementById('ls-progress-fill');
  const text = document.getElementById('ls-progress-text');
  if (fill) fill.style.width = (completed / total * 100) + '%';
  if (text) text.textContent = `⭐ ${completed * 3}/${total * 3} Stars Collected`;
}

function startLevel(worldIndex, levelIndex) {
  const level = levelsData.worlds[worldIndex].levels[levelIndex];
  GameState.currentLevel = level.id;
  GameState.currentWorld = worldIndex + 1;
  GameState.score = 0;
  GameState.moves = level.moves;
  GameState.time = level.time;
  GameState.target = level.target;
  GameState.tilesCleared = 0;
  GameState.hintsLeft = 3;
  GameState.undosLeft = 3;
  GameState.selectedTile = null;
  GameState.isAnimating = false;
  GameState.isPaused = false;
  GameState.grid = JSON.parse(JSON.stringify(level.grid));
  showScreen('gameplay');
  initGameplay();
}

// ========================
// GAMEPLAY
// ========================
function initGameplay() {
  updateHUD();
  renderGrid();
  startTimer();
  document.getElementById('gp-level-name').textContent = `Level ${GameState.currentLevel}`;

  // Tutorial for level 1
  if (GameState.currentLevel === 1) {
    setTimeout(() => showTutorial("Tap a tile then tap next to it to SWAP! Match 3 or more same colors!"), 500);
  }
}

function updateHUD() {
  document.getElementById('score-val').textContent = GameState.score;
  document.getElementById('moves-val').textContent = GameState.moves;
  document.getElementById('time-val').textContent = GameState.time;

  const pct = (GameState.tilesCleared / GameState.target) * 100;
  document.getElementById('target-fill').style.width = Math.min(pct, 100) + '%';
  document.getElementById('target-text').textContent = `${GameState.tilesCleared}/${GameState.target} tiles`;

  const movesEl = document.getElementById('moves-val');
  if (GameState.moves <= 3) movesEl.classList.add('danger');
  else movesEl.classList.remove('danger');

  const timeEl = document.getElementById('time-val');
  if (GameState.time <= 10) timeEl.classList.add('danger');
  else timeEl.classList.remove('danger');

  document.getElementById('hint-btn').textContent = `💡 Hint (${GameState.hintsLeft})`;
  document.getElementById('undo-btn').textContent = `↩ Undo (${GameState.undosLeft})`;
}

function renderGrid() {
  const grid = document.getElementById('game-grid');
  if (!grid) return;
  grid.innerHTML = '';

  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      const val = GameState.grid[r][c];
      const tile = document.createElement('div');
      tile.className = 'tile';
      tile.dataset.row = r;
      tile.dataset.col = c;

      if (val === 0) {
        tile.classList.add('tile-empty');
      } else if (val === 'L') {
        tile.classList.add(`tile-${getLockedBaseColor(r, c)}`, 'tile-locked');
      } else if (val === 'B') {
        tile.classList.add('tile-1');
        tile.textContent = '💣';
      } else if (val === 'R') {
        tile.classList.add('tile-5');
        tile.textContent = '🌈';
      } else {
        tile.classList.add(`tile-${val}`);
      }

      if (GameState.selectedTile && GameState.selectedTile.row === r && GameState.selectedTile.col === c) {
        tile.classList.add('selected');
      }

      tile.addEventListener('click', () => handleTileClick(r, c));
      grid.appendChild(tile);
    }
  }
}

function getLockedBaseColor(r, c) {
  return ((r + c) % 5) + 1;
}

function handleTileClick(row, col) {
  if (GameState.isAnimating || GameState.isPaused) return;
  if (GameState.moves <= 0) return;

  const val = GameState.grid[row][col];
  if (val === 0) return;

  if (!GameState.selectedTile) {
    GameState.selectedTile = { row, col };
    renderGrid();
    return;
  }

  const sel = GameState.selectedTile;
  if (sel.row === row && sel.col === col) {
    GameState.selectedTile = null;
    renderGrid();
    return;
  }

  const isAdjacent = (Math.abs(sel.row - row) === 1 && sel.col === col) ||
                     (Math.abs(sel.col - col) === 1 && sel.row === row);

  if (isAdjacent) {
    GameState.previousGrid = JSON.parse(JSON.stringify(GameState.grid));
    swapTiles(sel.row, sel.col, row, col);
    GameState.selectedTile = null;
    GameState.moves--;
    updateHUD();
  } else {
    GameState.selectedTile = { row, col };
    renderGrid();
  }
}

function swapTiles(r1, c1, r2, c2) {
  GameState.isAnimating = true;
  const temp = GameState.grid[r1][c1];
  GameState.grid[r1][c1] = GameState.grid[r2][c2];
  GameState.grid[r2][c2] = temp;
  renderGrid();
  setTimeout(() => {
    checkMatches();
  }, 200);
}

function checkMatches() {
  const matched = findMatches();
  if (matched.length === 0) {
    GameState.isAnimating = false;
    checkLoseCondition();
    return;
  }

  let scoreGain = 0;
  let tiles = new Set();

  matched.forEach(group => {
    group.forEach(([r, c]) => tiles.add(`${r},${c}`));
    if (group.length === 3) scoreGain += 30;
    else if (group.length === 4) scoreGain += 80;
    else scoreGain += 150;
  });

  tiles.forEach(key => {
    const [r, c] = key.split(',').map(Number);
    const val = GameState.grid[r][c];
    if (val === 'L') {
      GameState.grid[r][c] = getLockedBaseColor(r, c);
    } else if (val === 'B') {
      explodeBomb(r, c);
    } else {
      GameState.grid[r][c] = 0;
      GameState.tilesCleared++;
    }
  });

  GameState.score += scoreGain;
  showFloatingScore(scoreGain, matched.length);

  if (matched.length >= 2) showCombo(matched.length);

  updateHUD();
  dropTiles();
  setTimeout(() => {
    fillEmpty();
    renderGrid();
    setTimeout(() => {
      checkMatches();
    }, 300);
  }, 300);

  if (GameState.tilesCleared >= GameState.target) {
    setTimeout(winLevel, 400);
  }
}

function findMatches() {
  const matched = [];
  const grid = GameState.grid;

  // Check rows
  for (let r = 0; r < 4; r++) {
    let c = 0;
    while (c < 4) {
      const val = normalizeColor(grid[r][c]);
      if (!val) { c++; continue; }
      let end = c + 1;
      while (end < 4 && normalizeColor(grid[r][end]) === val) end++;
      if (end - c >= 3) {
        const group = [];
        for (let i = c; i < end; i++) group.push([r, i]);
        matched.push(group);
      }
      c = end;
    }
  }

  // Check columns
  for (let c = 0; c < 4; c++) {
    let r = 0;
    while (r < 4) {
      const val = normalizeColor(grid[r][c]);
      if (!val) { r++; continue; }
      let end = r + 1;
      while (end < 4 && normalizeColor(grid[end][c]) === val) end++;
      if (end - r >= 3) {
        const group = [];
        for (let i = r; i < end; i++) group.push([i, c]);
        matched.push(group);
      }
      r = end;
    }
  }

  return matched;
}

function normalizeColor(val) {
  if (!val || val === 0 || val === 'L') return null;
  if (val === 'R') return 'rainbow';
  if (val === 'B') return val;
  return val;
}

function explodeBomb(row, col) {
  for (let r = row - 1; r <= row + 1; r++) {
    for (let c = col - 1; c <= col + 1; c++) {
      if (r >= 0 && r < 4 && c >= 0 && c < 4) {
        if (GameState.grid[r][c] && GameState.grid[r][c] !== 'L') {
          GameState.grid[r][c] = 0;
          GameState.tilesCleared++;
        }
      }
    }
  }
}

function dropTiles() {
  for (let c = 0; c < 4; c++) {
    const col = [];
    for (let r = 0; r < 4; r++) {
      if (GameState.grid[r][c] !== 0) col.push(GameState.grid[r][c]);
    }
    while (col.length < 4) col.unshift(0);
    for (let r = 0; r < 4; r++) GameState.grid[r][c] = col[r];
  }
}

function fillEmpty() {
  const colors = [1, 2, 3, 4, 5];
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      if (GameState.grid[r][c] === 0) {
        GameState.grid[r][c] = colors[Math.floor(Math.random() * colors.length)];
      }
    }
  }
}

function showFloatingScore(points, combos) {
  const grid = document.getElementById('game-grid-wrapper');
  if (!grid) return;
  const el = document.createElement('div');
  el.className = 'float-text';
  el.textContent = '+' + points;
  el.style.left = (80 + Math.random() * 160) + 'px';
  el.style.top = (100 + Math.random() * 100) + 'px';
  el.style.color = combos >= 2 ? '#f59e0b' : 'white';
  grid.appendChild(el);
  setTimeout(() => el.remove(), 800);
}

function showCombo(count) {
  const overlay = document.getElementById('combo-overlay');
  if (!overlay) return;
  const el = document.createElement('div');
  el.className = 'combo-text';
  const messages = ['GREAT!', 'COMBO!', 'AMAZING!', 'UNSTOPPABLE!'];
  const colors = ['#10b981', '#f59e0b', '#ef4444', '#8b5cf6'];
  el.textContent = messages[Math.min(count - 2, 3)];
  el.style.color = colors[Math.min(count - 2, 3)];
  overlay.innerHTML = '';
  overlay.appendChild(el);
  setTimeout(() => overlay.innerHTML = '', 600);
}

// ========================
// TIMER
// ========================
function startTimer() {
  clearInterval(GameState.timer);
  GameState.timer = setInterval(() => {
    if (GameState.isPaused) return;
    GameState.time--;
    updateHUD();
    if (GameState.time <= 0) {
      clearInterval(GameState.timer);
      loseLevel('TIME\'S UP!');
    }
  }, 1000);
}

// ========================
// WIN / LOSE
// ========================
function checkLoseCondition() {
  if (GameState.moves <= 0 && GameState.tilesCleared < GameState.target) {
    clearInterval(GameState.timer);
    setTimeout(() => loseLevel('OUT OF MOVES!'), 300);
  }
}

function winLevel() {
  clearInterval(GameState.timer);
  const stars = GameState.moves >= 8 ? 3 : GameState.moves >= 4 ? 2 : 1;
  const coins = (levelsData?.worlds[GameState.currentWorld - 1]?.levels[GameState.currentLevel - 1]?.coins || 30) * stars;

  GameState.coins += coins;
  const key = `w${GameState.currentWorld}_l${GameState.currentLevel}`;
  GameState.completedLevels[key] = true;
  GameState.levelStars[key] = Math.max(GameState.levelStars[key] || 0, stars);
  saveProgress();

  // Show win screen
  document.getElementById('win-stars').textContent = '⭐'.repeat(stars) + '☆'.repeat(3 - stars);
  document.getElementById('win-score').textContent = GameState.score.toLocaleString() + ' pts';
  document.getElementById('win-coins').textContent = '+' + coins + ' 🪙';
  createConfetti();
  showScreen('win');
}

function loseLevel(reason) {
  document.getElementById('lose-reason').textContent = reason;
  document.getElementById('lose-score').textContent = 'Score: ' + GameState.score;
  showScreen('lose');
}

function createConfetti() {
  const container = document.getElementById('confetti-container');
  if (!container) return;
  container.innerHTML = '';
  const colors = ['#ef4444', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ffffff'];
  for (let i = 0; i < 40; i++) {
    const piece = document.createElement('div');
    piece.className = 'confetti-piece';
    piece.style.left = Math.random() * 100 + '%';
    piece.style.background = colors[Math.floor(Math.random() * colors.length)];
    piece.style.animationDuration = (2 + Math.random() * 2) + 's';
    piece.style.animationDelay = (Math.random() * 1) + 's';
    piece.style.borderRadius = Math.random() > 0.5 ? '50%' : '0';
    container.appendChild(piece);
  }
}

// ========================
// HINT SYSTEM
// ========================
function showHint() {
  if (GameState.hintsLeft <= 0) return;
  const move = findBestMove();
  if (!move) return;
  GameState.hintsLeft--;
  updateHUD();
  const tiles = document.querySelectorAll('.tile');
  const idx1 = move.r1 * 4 + move.c1;
  const idx2 = move.r2 * 4 + move.c2;
  tiles[idx1]?.classList.add('hint-glow');
  tiles[idx2]?.classList.add('hint-glow');
  setTimeout(() => {
    tiles[idx1]?.classList.remove('hint-glow');
    tiles[idx2]?.classList.remove('hint-glow');
  }, 2000);
}

function findBestMove() {
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 4; c++) {
      // Try swap right
      if (c < 3) {
        const testGrid = JSON.parse(JSON.stringify(GameState.grid));
        const temp = testGrid[r][c]; testGrid[r][c] = testGrid[r][c+1]; testGrid[r][c+1] = temp;
        if (hasMatch(testGrid)) return { r1: r, c1: c, r2: r, c2: c+1 };
      }
      // Try swap down
      if (r < 3) {
        const testGrid = JSON.parse(JSON.stringify(GameState.grid));
        const temp = testGrid[r][c]; testGrid[r][c] = testGrid[r+1][c]; testGrid[r+1][c] = temp;
        if (hasMatch(testGrid)) return { r1: r, c1: c, r2: r+1, c2: c };
      }
    }
  }
  return null;
}

function hasMatch(grid) {
  for (let r = 0; r < 4; r++) {
    for (let c = 0; c < 2; c++) {
      const v = normalizeColor(grid[r][c]);
      if (v && v === normalizeColor(grid[r][c+1]) && v === normalizeColor(grid[r][c+2])) return true;
    }
  }
  for (let c = 0; c < 4; c++) {
    for (let r = 0; r < 2; r++) {
      const v = normalizeColor(grid[r][c]);
      if (v && v === normalizeColor(grid[r+1][c]) && v === normalizeColor(grid[r+2][c])) return true;
    }
  }
  return false;
}

// ========================
// UNDO
// ========================
function undoMove() {
  if (GameState.undosLeft <= 0 || !GameState.previousGrid) return;
  GameState.grid = JSON.parse(JSON.stringify(GameState.previousGrid));
  GameState.moves++;
  GameState.undosLeft--;
  updateHUD();
  renderGrid();
}

// ========================
// PAUSE
// ========================
function togglePause() {
  GameState.isPaused = !GameState.isPaused;
  const overlay = document.getElementById('pause-overlay');
  if (overlay) overlay.classList.toggle('active', GameState.isPaused);
}

// ========================
// TUTORIAL
// ========================
function showTutorial(text) {
  const el = document.getElementById('tutorial-text');
  const box = document.getElementById('tutorial-box');
  if (el) el.textContent = text;
  if (box) {
    box.style.display = 'block';
    setTimeout(() => box.style.display = 'none', 3000);
  }
}

// ========================
// SHOP
// ========================
function initShop() {
  updateCoinDisplay();
  updateShopDisplay();
}

function updateShopDisplay() {
  document.querySelectorAll('.shop-coins').forEach(el => {
    el.textContent = '🪙 ' + GameState.coins;
  });
}

function buyItem(itemId, cost, type) {
  if (GameState.coins < cost) {
    alert('Not enough coins! 🪙');
    return;
  }
  GameState.coins -= cost;
  if (type === 'hint') GameState.hintsLeft += 5;
  if (type === 'undo') GameState.undosLeft += 5;
  saveProgress();
  updateShopDisplay();
  updateCoinDisplay();
  alert('Purchased! ✅');
}

// ========================
// INIT ON LOAD
// ========================
window.addEventListener('DOMContentLoaded', () => {
  loadProgress();
  initSplash();

  // Button events
  document.getElementById('play-btn')?.addEventListener('click', () => {
    showScreen('levelselect');
    initLevelSelect();
  });

  document.getElementById('shop-btn')?.addEventListener('click', () => {
    showScreen('shop');
    initShop();
  });

  document.getElementById('settings-btn')?.addEventListener('click', () => {
    showScreen('settings');
  });

  document.getElementById('leaderboard-btn')?.addEventListener('click', () => {
    showScreen('leaderboard');
  });

  // Back buttons
  document.querySelectorAll('.back-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      clearInterval(GameState.timer);
      showScreen('home');
      initHome();
    });
  });

  // Gameplay buttons
  document.getElementById('hint-btn')?.addEventListener('click', showHint);
  document.getElementById('undo-btn')?.addEventListener('click', undoMove);
  document.getElementById('pause-btn')?.addEventListener('click', togglePause);
  document.getElementById('resume-btn')?.addEventListener('click', togglePause);

  // Win screen
  document.getElementById('next-level-btn')?.addEventListener('click', () => {
    const nextLevel = GameState.currentLevel + 1;
    const world = levelsData?.worlds[GameState.currentWorld - 1];
    if (world && nextLevel <= world.levels.length) {
      startLevel(GameState.currentWorld - 1, nextLevel - 1);
    } else {
      showScreen('levelselect');
      initLevelSelect();
    }
  });

  document.getElementById('replay-btn')?.addEventListener('click', () => {
    startLevel(GameState.currentWorld - 1, GameState.currentLevel - 1);
  });

  document.getElementById('win-home-btn')?.addEventListener('click', () => {
    showScreen('home');
    initHome();
  });

  // Lose screen
  document.getElementById('retry-btn')?.addEventListener('click', () => {
    startLevel(GameState.currentWorld - 1, GameState.currentLevel - 1);
  });

  document.getElementById('lose-home-btn')?.addEventListener('click', () => {
    showScreen('home');
    initHome();
  });
});
